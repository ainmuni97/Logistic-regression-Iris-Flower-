from flask import Flask,render_template, redirect, url_for, session
from flask_wtf import FlaskForm
from wtforms import TextField, SubmitField
from wtforms.validators import NumberRange
from joblib import dump, load


app = Flask(__name__)

app.config['SECRET_KEY'] = 'mysunshine'

class FlowerForm(FlaskForm):
    sep_len = TextField('Sepal_Length')
    sep_wid = TextField('Sepal_Width')
    pet_len = TextField('Petal_Length')
    pet_wid = TextField('Petal_Width')

    submit = SubmitField('Analyze')



@app.route('/', methods = ['POST', 'GET'])
def index():

    # Create instance of the Form
    form = FlowerForm()

    #if the form is valis on submission(we'll talk about validation next)
    if form.validate_on_submit():
        # Grab the data from the breed on the form.

        session['sep_len'] = form.sep_len.data
        session['sep_wid'] = form.sep_wid.data
        session['pet_len'] = form.pet_len.data
        session['pet_wid'] = form.pet_wid.data
        print (form.sep_len.data)
        print (form.sep_wid.data)
        print (form.pet_len.data)
        print (form.pet_wid.data)

        return redirect(url_for('prediction'))

    return render_template('home.html', form = form)

#3 Add the return_prediction()

def return_prediction(model, scaler, sample_json):
    
    # For larger data features, you should probably write a for-loop
    # That builds out this array for you
    
    s_len = sample_json['sepal_length']
    s_wid = sample_json['sepal_width']
    p_len = sample_json['petal_length']
    p_wid = sample_json['petal_width']
    
    flower = [[s_len, s_wid, p_len, p_wid]]
    
    flower = scaler.transform(flower)
    
    #classes = np.array(['setosa', 'versicolor', 'virginica'])
    
    prediction = model.predict(flower)
    
    return prediction[0]

#1 Load the Model
#2 Load the Scaler

flowermodel = load('final_iris_model.h5')
flowerscaler = load('iris_scaler.pkl')

@app.route('/prediction', methods = ['POST'])
def predict_flower():

    content = request.json

    results = return_prediction(model = flowermodel, scaler = flowerscaler, sample_json = content)

    return jsonify(results)

if __name__ == '__main__':
    app.run()